Put your band's MP3 files in this folder using these exact names:
- last-night.mp3
- version-of-you.mp3
- faith-in-him.mp3
