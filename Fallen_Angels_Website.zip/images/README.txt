Put band photos, album artwork, logos, and member photos in this folder.
Suggested files:
- band.jpg
- logo.png
- last-night.jpg
- member-guitar.jpg
- member-vocals.jpg
